def sum_tuples(tlst):
    return [t[0] + t[1] for t in tlst]