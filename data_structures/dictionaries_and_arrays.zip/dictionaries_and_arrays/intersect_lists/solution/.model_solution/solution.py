def update_dict(key,value):
    create_dict_ = {}
    create_dict[key] = value
    return create_dict
