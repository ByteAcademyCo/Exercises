def intersect_lists(lst1, lst2):
    return [x for x in lst1 if x in lst2]