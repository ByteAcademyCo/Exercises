# Exercises for Classes


| Exercise ID | Exercise |
|:-----------:|:--------:|
| easy_e1 | [Employee Class](https://github.com/ByteAcademyCo/Introduction-To-Python/tree/master/exercises/classes/employee_class) |
| easy_e2 | [Employee Raise](https://github.com/ByteAcademyCo/Introduction-To-Python/tree/master/exercises/classes/employee_raise) |
| easy_e3 | [Employee Sort](https://github.com/ByteAcademyCo/Introduction-To-Python/tree/master/exercises/classes/employee_sort) |
| medium_e1 | [Calendar Clock](https://github.com/ByteAcademyCo/Introduction-To-Python/tree/master/exercises/classes/calendar_clock) |
| medium_e2 | [Person Child](https://github.com/ByteAcademyCo/Introduction-To-Python/tree/master/exercises/classes/person_child) |
| medium_e2 | [Person Get Sibilings](https://github.com/ByteAcademyCo/Introduction-To-Python/tree/master/exercises/classes/person_get_sibilings) |
| medium_e3 | [Person Get Married](https://github.com/ByteAcademyCo/Introduction-To-Python/tree/master/exercises/classes/2_string_parenthesis) |
| medium_e4 | [Person Get Divorced](https://github.com/ByteAcademyCo/Introduction-To-Python/tree/master/exercises/classes/person_get_divorced) |
| hard_e1 | [Person Give Birth](https://github.com/ByteAcademyCo/Introduction-To-Python/tree/master/exercises/classes/person_give_birth) |
| hard_e2 | [Student Highest Average](https://github.com/ByteAcademyCo/Introduction-To-Python/tree/master/exercises/classes/student_highest_average) |
