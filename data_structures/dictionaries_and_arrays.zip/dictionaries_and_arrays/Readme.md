# Introduction To Arrays and Dictionary Exercises

| Exercise ID | Exercise |
|:-----------:|:--------:|
| easy_e1 | [Create_Array](https://github.com/ByteAcademyCo/Data-Structures/tree/Arrays/exercises/dictionaries_and_arrays/1.Create_Array) |
| easy_e2 | [Insert_element](https://github.com/ByteAcademyCo/Data-Structures/tree/Arrays/exercises/dictionaries_and_arrays/1.Insert_element) |
| easy_e3 | [create_update_dict](https://github.com/ByteAcademyCo/Data-Structures/tree/Arrays/exercises/dictionaries_and_arrays/1.create_update_dict) |
| easy_e4 | [print_dictionary](https://github.com/ByteAcademyCo/Data-Structures/tree/Arrays/exercises/dictionaries_and_arrays/1.print_dictionary) |
| medium_e1 | [Occurance](https://github.com/ByteAcademyCo/Data-Structures/tree/Arrays/exercises/dictionaries_and_arrays/2.Occurance) |
| medium_e2 | [Reverse_Array](https://github.com/ByteAcademyCo/Data-Structures/tree/Arrays/exercises/dictionaries_and_arrays/2.Reverse_Array%20) |
| medium_e3 | [Sort_values](https://github.com/ByteAcademyCo/Data-Structures/tree/Arrays/exercises/dictionaries_and_arrays/2.Sort_values) |
| medium_e4 | [convert_JSON](https://github.com/ByteAcademyCo/Exercises/tree/master/introduction_and_environment/introduction_to_programming/2_type_check) |
| hard_e1 | [Difference](https://github.com/ByteAcademyCo/Data-Structures/tree/Arrays/exercises/dictionaries_and_arrays/3.Difference) |
| hard_e2 | [square_keys](https://github.com/ByteAcademyCo/Data-Structures/tree/Arrays/exercises/dictionaries_and_arrays/3.square_keys) |