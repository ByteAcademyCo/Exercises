def squares_dict(n):
    return {x: x*x for x in range(1, n+1)}